﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace Server
{
    class Main
    {
        public void MainThread()
        {
            Value.Path="D:\\PT_Server";
            Value.CFG = new Configs(Value.Path);
            Value.WriteLog = new Log(Value.Path, LogType.LT_All);
            while (true)
            {
                Thread.Sleep(1000);
                Value.WriteLog.WriteLine("fsadfdsaf", LogType.LT_Infor);
            }
        }
    }
}
