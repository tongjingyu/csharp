﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    class Configs
    {
        private string Path;
        public Configs(string Path)
        {
            this.Path=Path;
        }
        public void Load()
        {

        }
    }
}
