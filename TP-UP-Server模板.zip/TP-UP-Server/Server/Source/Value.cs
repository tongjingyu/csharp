﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    enum LogType
    {
        LT_Error = 1,
        LT_Warning = 2,
        LT_Infor = 3,
        LT_All=7
    }
    enum SoftType
    {
       ST_Console = 1,
       ST_Server = 2
    }
    class TagetValue
    {
        public static LogType SystemLogType = LogType.LT_All;
        public static SoftType SystemType = SoftType.ST_Console;
        public static bool Run = true;
    }
    class Value
    {
        public static string Path;
        public static Configs CFG;
        public static Log WriteLog;
    }
}
